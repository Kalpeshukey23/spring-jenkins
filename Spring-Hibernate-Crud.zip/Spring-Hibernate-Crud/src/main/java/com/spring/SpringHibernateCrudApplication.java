package com.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHibernateCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringHibernateCrudApplication.class, args);
	}

}
