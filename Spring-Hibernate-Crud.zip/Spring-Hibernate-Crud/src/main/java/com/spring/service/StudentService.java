package com.spring.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.hibernate.query.criteria.internal.BasicPathUsageException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.custom.Exception.BusinessException;
import com.spring.dao.StudentDao;
import com.spring.entity.Student;

@Service
public class StudentService implements StudentServiceInterface {

	@Autowired
	private StudentDao studentDao;

	@Override
	public Student addStudent(Student student) {

		if (student.getName().isEmpty() || student.getName().length() == 0) {

			throw new BusinessException("601", "Please send proper name, Its Blank");
		}
		try {
			Student savedStd = studentDao.save(student);
			return savedStd;

		}

		catch (IllegalArgumentException e) {
			throw new BusinessException("602", "Given employee is null" + e.getMessage());
		}

		catch (Exception e) {
			throw new BusinessException("603", "SomeThing is wrong in Service layer" + e.getMessage());
		}
	}

	@Override
	public List<Student> getAll() {
		try {
			List<Student> stdLst = studentDao.findAll();
			if (stdLst.isEmpty())
				throw new BusinessException("604", "HEY List is empty");
			return stdLst;
		} catch (Exception e) {
			throw new BusinessException("605", "Something is wrong while fetching in Service layer" + e.getMessage());
		}

	}

	@Override
	public Student getStudentById(int id) {

		try {
			return studentDao.findById(id).get();
		} catch (IllegalArgumentException e) {
			throw new BusinessException("606", "given employee id is null" + e.getMessage());
		} catch (NoSuchElementException e) {
			throw new BusinessException("607", "given employee doesnt exist in DB" + e.getMessage());
		}

	}

	@Override
	public void deleteById(int id) {
		try {
			studentDao.deleteById(id);
		} catch (IllegalArgumentException e) {
			throw new BusinessException("608", "given employee id is null,please provide valid ID" + e.getMessage());
		}

	}
}
