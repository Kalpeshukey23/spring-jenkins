package com.spring.service;

import java.util.List;

import com.spring.entity.Student;

public interface StudentServiceInterface {

	public Student addStudent(Student student);

	public List<Student> getAll();

	public Student getStudentById(int id);

	public void deleteById(int id);

}
