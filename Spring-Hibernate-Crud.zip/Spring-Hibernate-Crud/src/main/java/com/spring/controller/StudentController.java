package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.custom.Exception.BusinessException;
import com.spring.custom.Exception.ControllerException;
import com.spring.entity.Student;
import com.spring.service.StudentServiceInterface;

@RestController
@RequestMapping(path = "/student")
public class StudentController {

	@Autowired
	private StudentServiceInterface serviceInterface;

	@PostMapping(path = "/addStudent")
	public ResponseEntity<?> addStudent(@RequestBody Student student) {

		try {
			Student savedStd = serviceInterface.addStudent(student);
			return new ResponseEntity<Student>(savedStd, HttpStatus.CREATED);
		} catch (BusinessException e) {
			ControllerException cr = new ControllerException(e.getErrorCode(), e.getErrorMessage());
			return new ResponseEntity<ControllerException>(cr, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			ControllerException cr1 = new ControllerException("611", "Something is wrong is Controller");
			return new ResponseEntity<ControllerException>(cr1, HttpStatus.BAD_REQUEST);
		}

	}

	@GetMapping(path = "/all")
	public ResponseEntity<List<Student>> getAll() {

		List<Student> lstStudent = serviceInterface.getAll();
		return new ResponseEntity<List<Student>>(lstStudent, HttpStatus.OK);
	}

	@GetMapping(path = "/getStudent/{id}")
	public ResponseEntity<?> getStudentById(@PathVariable("id") int id) {

		try {
			Student getByID = serviceInterface.getStudentById(id);
			return new ResponseEntity<Student>(getByID, HttpStatus.OK);

		} catch (BusinessException e) {
			ControllerException cr = new ControllerException(e.getErrorCode(), e.getErrorMessage());
			return new ResponseEntity<ControllerException>(cr, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			ControllerException cr1 = new ControllerException("611", "Something is wrong is Controller");
			return new ResponseEntity<ControllerException>(cr1, HttpStatus.BAD_REQUEST);
		}

	}

	@DeleteMapping(path = "/delete/{id}")
	public ResponseEntity<Void> deleteStd(@PathVariable("id") int id) {
		serviceInterface.deleteById(id);
		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	}

	@PutMapping(path = "/update")
	public ResponseEntity<Student> updateStd(@RequestBody Student std) {
		Student update = serviceInterface.addStudent(std);
		return new ResponseEntity<Student>(update, HttpStatus.CREATED);
	}

}
