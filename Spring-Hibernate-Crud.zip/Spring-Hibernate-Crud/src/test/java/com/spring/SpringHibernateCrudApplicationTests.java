package com.spring;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.spring.dao.StudentDao;
import com.spring.entity.Student;
import com.spring.service.StudentServiceInterface;

@SpringBootTest
class SpringHibernateCrudApplicationTests {

	@Autowired
	private StudentServiceInterface serviceInterface;

	@MockBean
	private StudentDao studentDao;     

	@Test
	public void getAllStudentTest() {
		when(studentDao.findAll()).thenReturn(Stream.of(new Student(1, "kalpesh")).collect(Collectors.toList()));
		assertEquals(1, serviceInterface.getAll().size());

	}

	@Test
	public void saveStudentTest() {
		Student std = new Student(3, "Jatin");
		when(studentDao.save(std)).thenReturn(std);
		assertEquals(std, serviceInterface.addStudent(std));

	}

	@Test
	public void deleteStudentTest() {

		Student std = new Student(4, "Shivam");
		serviceInterface.deleteById(std.getId());
		verify(studentDao, times(1)).deleteById(std.getId());

	}

	@Test
	public void getStudentByIDTest() {

		Student s = new Student(1, "kunal");
		Mockito.when(studentDao.getById(1)).thenReturn(s);
		assertEquals(s, studentDao.getById(1));

	}


}
